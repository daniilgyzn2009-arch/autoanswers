AutoAnswer Plugin for ChatGPT

Генерирует спокойные, уверенные и тёплые ответы на сообщения.

Возможности:
- 3 режима: calm (по умолчанию), confident, warm
- Простая интеграция в ChatGPT
- Работает с контекстом переписки

Запуск на Vercel:
1. Создать проект на https://vercel.com
2. Залить эту папку как проект
3. Добавить переменную окружения:
   OPENAI_API_KEY = твой ключ OpenAI
4. Нажать Deploy

Подключение к ChatGPT:
URL манифеста:
https://autoanswer.vercel.app/.well-known/manifest.json